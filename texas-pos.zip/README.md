# TEXAS POS (Starter)

ระบบ POS สำหรับใช้งานภายในร้าน TEXAS ผ่าน iPhone Pro Max

- รองรับ Mobile-first
- พัฒนาแบบ Static Web
- พร้อมเชื่อมต่อ Supabase
