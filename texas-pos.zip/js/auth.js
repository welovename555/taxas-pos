function login() {
  const code = document.getElementById("code").value;
  alert("กำลังเข้าสู่ระบบด้วยรหัส: " + code);
  // TODO: เชื่อมกับ Supabase เพื่อตรวจสอบพนักงาน
}
